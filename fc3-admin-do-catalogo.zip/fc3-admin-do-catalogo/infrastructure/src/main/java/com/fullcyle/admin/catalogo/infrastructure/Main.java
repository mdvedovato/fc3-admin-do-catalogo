package com.fullcyle.admin.catalogo.infrastructure;

import com.fullcyle.admin.catalogo.application.UserCase;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        System.out.println(new UserCase().execute());
    }
}