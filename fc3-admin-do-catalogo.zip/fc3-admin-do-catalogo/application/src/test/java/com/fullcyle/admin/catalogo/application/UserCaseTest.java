package com.fullcyle.admin.catalogo.application;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class UserCaseTest {

    @Test
    public void testCreateUseCase() {
        Assertions.assertNotNull(new UserCase());
        Assertions.assertNotNull(new UserCase().execute());
    }

}
