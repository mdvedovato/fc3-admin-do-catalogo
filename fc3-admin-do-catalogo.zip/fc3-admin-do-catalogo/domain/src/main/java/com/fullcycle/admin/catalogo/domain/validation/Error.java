package com.fullcycle.admin.catalogo.domain.validation;

public record Error(String message) {
        }