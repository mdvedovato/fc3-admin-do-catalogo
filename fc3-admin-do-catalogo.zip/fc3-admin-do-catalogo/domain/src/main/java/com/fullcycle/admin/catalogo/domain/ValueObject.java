package com.fullcycle.admin.catalogo.domain;

public abstract class ValueObject {

}
