package com.fullcycle.admin.catalogo.domain;

public abstract class Identifier extends ValueObject {
    public abstract String getValue();

}